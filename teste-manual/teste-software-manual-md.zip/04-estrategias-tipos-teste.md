# 04 - Estrategias tipos teste

## 🧠 O que aprendi:

- 

## 📝 Anotações importantes:

- 

## 💬 Exemplo real:

- 
