# 08 - Upstream

## 🧠 O que aprendi:

- 

## 📝 Anotações importantes:

- 

## 💬 Exemplo real:

- 
