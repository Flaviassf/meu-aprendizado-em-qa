# 09 - Pratica upstream

## 🧠 O que aprendi:

- 

## 📝 Anotações importantes:

- 

## 💬 Exemplo real:

- 
