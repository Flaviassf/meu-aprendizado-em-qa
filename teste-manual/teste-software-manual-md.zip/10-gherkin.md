# 10 - Gherkin

## 🧠 O que aprendi:

- 

## 📝 Anotações importantes:

- 

## 💬 Exemplo real:

- 
