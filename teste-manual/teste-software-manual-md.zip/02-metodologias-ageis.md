# 02 - Metodologias ageis

## 🧠 O que aprendi:

- 

## 📝 Anotações importantes:

- 

## 💬 Exemplo real:

- 
